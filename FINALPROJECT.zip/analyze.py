import sqlite3
import pandas as pd

conn = sqlite3.connect("FINALPROJECTDB.db")

# --- JOIN + INCOME BRACKETING + CALCULATION ---
query = """
SELECT 
    CASE
        WHEN income.median_income < 50000 THEN '<50k'
        WHEN income.median_income BETWEEN 50000 AND 74999 THEN '50–75k'
        WHEN income.median_income BETWEEN 75000 AND 99999 THEN '75–100k'
        ELSE '100k+'
    END AS income_bracket,
    ROUND(1.0 * SUM(restaurants.review_count) / COUNT(restaurants.id), 2) AS avg_reviews_per_restaurant,
    COUNT(DISTINCT income.zip_code) AS zip_count
FROM income
JOIN education ON income.zip_code = education.zip_code
JOIN restaurants ON income.zip_code = restaurants.zip_code
GROUP BY income_bracket
ORDER BY income_bracket;
"""

df = pd.read_sql_query(query, conn)

# Save to .txt file
with open("calculated_data.txt", "w") as f:
    f.write("Average Yelp Reviews per Restaurant by Income Bracket:\n\n")
    f.write(df.to_string(index=False))

print("✅ Wrote income-based average review data to calculated_data.txt")

conn.close()